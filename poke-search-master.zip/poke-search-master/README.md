# poke-search
A API based Pokemon search React-Native app.
